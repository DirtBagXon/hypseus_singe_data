## Marbella Vice (HYPSEUS SINGE MULTIPLAYER EDITION)

The files in this package should be installed alongside the required game video (m2v) and mullti language (-es) audio (ogg) files.

Hypseus Singe version 2.11.5 or above is required for this game.

You will need to place the files from this package into your marbvice folder, alongside the m2v and ogg files.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- marbvice.daphne
|    |    |
|    |    |-- marbvice.m2v       (New 2-player media)
|    |    |-- marbvice.ogg       (English Audio)
|    |    |-- marbvice-es.ogg    (Spanish Audio)
|    |    |-- marbvice.zip       (Main LUA ZIP ROM file)
|    |    |-- marbvice.txt       (Framefile from install zip)
|    |    |-- marbvice.commands  (Optional)
|    |    |
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- marbvice
|    |    |
|    |    |-- marbvice.m2v       (New 2-player media)
|    |    |-- marbvice.ogg       (English Audio)
|    |    |-- marbvice-es.ogg    (Spanish Audio)
|    |    |-- marbvice.zip       (Main LUA ZIP ROM file)
|    |    |-- marbvice.txt       (Framefile from install zip)
|    |    |
|    |
