## FAST DRAW SHOWDOWN (HYPSEUS SINGE MULTIPLAYER EDITION)

The files in this package should be installed alongside the required game video (m2v) and audio (ogg) files. These are new video and audio files.

You will need to place the files from this package into your fastdraw folder, alongside new m2v and ogg files from archive.org.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- fastdraw.daphne
|    |    |
|    |    |-- fastdraw-extra.m2v (extras media)
|    |    |-- fastdraw.m2v       (2-player media)
|    |    |-- fastdraw.ogg       (2-player media)
|    |    |-- fastdraw.zip       (Main LUA ZIP ROM file)
|    |    |-- fastdraw.txt       (Framefile from install zip)
|    |    |-- fastdraw.commands  (Optional)
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- fastdraw
|    |    |
|    |    |-- fastdraw-extra.m2v (extras media)
|    |    |-- fastdraw.m2v       (2-player media)
|    |    |-- fastdraw.ogg       (2-player media)
|    |    |-- fastdraw.zip       (Main LUA ZIP ROM file)
|    |    |-- fastdraw.txt       (Framefile from install zip)
|    |


OPTIONS MENU:
- Draws/Game: the number of enemies you face in a single playthrough. Winning all of these allows you to try the bonus draw.
- Holster: "Button" requires the user to hold either the right mouse button or the skill button (skill 1 for player 1 and skill 2 for player 2) in order to keep the gun holstered. "Point" requires the user to point the gun offscreen (if using a lightgun) or keep the cursor on
 the edge of the screen (if using a mouse) to keep the gun holstered. "None" removes the holster requirement entirely.
- Crosshairs: various choices, including animated hand cursors and disabling cursors.
- Delay: the amount of time before the enemy reaches for his/her gun that the player(s) is/are prompted to draw. For example, if set to 0:00, "DRAW" will appear at the exact instant the enemy starts reaching for his/her gun. If instead set to 0:09, "DRAW" appears 0.09 seconds
 earlier (giving the player(s) an advantage). Defaults are similar to arcade defaults. Each difficulty (and bonus) has its own delay setting.

RULES FOR 1-PLAYER GAMES:
- If Holster is set to Button or Point and the gun is not holstered when a scene begins, then "HOLSTER" will appear inside of a red oval until the user holsters the gun. If the gun is not yet holstered when it is time for "DRAW" to appear, a warning will be issued. Up to 2 wa
rnings can be issued per game. After that, fouls will be declared. A foul is an automatic fail for that draw.
- If the gun is holstered during this HOLSTER phase, or if it is already holstered when the scene begins, then the oval will flash red/yellow and show "READY."
- If the gun gets unholstered during the READY phase, then a warning will be issued (or a foul, if 2 warnings have already been issued). Otherwise, the oval will eventually change to green and show "DRAW." At this point, the player can attempt to shoot the enemy. The player h
as 6 bullets per draw and cannot reload.
- Pulling the trigger or pausing the game at any point before DRAW appears is an automatic foul.
- If Holster is set to None, then the HOLSTER phase does not exist. There are also no warnings.
- In draws involving two enemies, each enemy has his/her own HOLSTER, READY, and DRAW phases. If the player beats both enemies, then the lower of the two win times will count. The par time shown is for the active enemy. If the player beats the first enemy but loses to the sec
ond in a two-enemy draw, then the time earned on the first enemy is forfeited. Said time is also forfeited if a warning or foul is declared when facing the second enemy.

RULES SPECIFIC TO 2-PLAYER GAMES:
- Flashing half-ovals are used to indicate who is holstered/unholstered.
- The first player to commit an infraction in a particular draw is booted out of that draw and treated as if he/she failed the draw. The gameplay then reverts to 1-player mode for the other player for the remainder of that draw. An infraction is anything that would give a war
ning or foul. To clarify a specific case, HOLSTER only transitions to READY when both players are holstered. If one player is holstered and the other is not when HOLSTER attempts to transition to DRAW, then the unholstered player is kicked out while the holstered player may d
raw and shoot as normal.
- A draw can only give a warning or foul if both players have committed an infraction. The first player to commit an infraction is removed from the draw, and the remaining player's infraction determines whether a warning or foul is declared. The two-warning limit is shared be
tween both players.
- Each player has 6 bullets per draw.

GENERAL NOTES:
- The time shown on the left side of the screen during gameplay is the amount of time from when DRAW appears until the enemy shoots (the par time).
- The time shown on the right side of the screen during gameplay is the players' time. It will show red numbers if player 1 has the winning time and blue numbers if player 2 has the winning time. Only the lowest time counts towards high scores in two-enemy draws. ?:?? will sh
ow in white here otherwise.
- If you want to play the game in portrait mode, set your monitor to display in portrait mode and use -vertical_screen when launching the game.
- For Sinden users: if using a border that is longer vertically than horizontally, then disable "gangsta mode" in the Sinden settings. Otherwise, the gun will think it is turned sideways. If using a border that is wider than the game video, then use -xratio number, where numb
er is the border's aspect ratio as a fraction divided by the game's aspect ratio as a fraction. For example, playing Fast Draw Showdown (3:4 video) with a 16:9 border will require that number to be (16/9) / (3/4) = 64/27, which is approximately 2.37. Then you'd use -xratio 2.
37 to get proper alignment with your gun(s). It is also suggested to use -scalefactor to shrink the game video slightly to fit inside of a border generated from a bezel image so that none of the game screen is covered.
