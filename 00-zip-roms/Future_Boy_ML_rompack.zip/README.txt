## CONAN IL RAGAZZO DEL FUTURO multi-language edition

The files in this package should be installed alongside the required game video (m2v) and mullti language (-it) audio (ogg) files.

Hypseus Singe version 2.11.5 or above is required for this game.

You will need to place the files from this package into your conan folder, alongside the m2v and ogg files - Note: These are newly re-created 4:3 ratio files for this release.

Note: This version uses a full overlay and is not usually suitable for SBC's.

for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- Future_Boy
|    |    |
|    |    |-- Future_Boy.zip       (Main LUA ZIP ROM file)
|    |    |-- Future_Boy.txt       (Framefile from install zip)
|    |    |-- Video
|    |    |-- |
|    |    |   |-- conan.m2v
|    |    |   |-- conan.ogg
|    |    |   |-- conan-it.ogg
|    |    |
|    |
