## Tierras Salvajes (HYPSEUS SINGE MULTIPLAYER EDITION)

The files in this package should be installed alongside the required game video (m2v) and mullti language (-es) audio (ogg) files.

Hypseus Singe version 2.11.6 or above is required for this game.

You will need to place the files from this package into your tierras folder, alongside the m2v and ogg files.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- tierras.daphne
|    |    |
|    |    |-- tierras.m2v       (New 2-player media)
|    |    |-- tierras.ogg       (English Audio)
|    |    |-- tierras-es.ogg    (Spanish Audio)
|    |    |-- tierras.zip       (Main LUA ZIP ROM file)
|    |    |-- tierras.txt       (Framefile from install zip)
|    |    |-- tierras.commands  (Optional)
|    |    |
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- tierras
|    |    |
|    |    |-- tierras.m2v       (New 2-player media)
|    |    |-- tierras.ogg       (English Audio)
|    |    |-- tierras-es.ogg    (Spanish Audio)
|    |    |-- tierras.zip       (Main LUA ZIP ROM file)
|    |    |-- tierras.txt       (Framefile from install zip)
|    |    |
|    |
