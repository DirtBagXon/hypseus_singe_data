-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
-- Sega Video Driver / Family Driver Simulator
-- Written by Widge for Hypseus Singe, 2024
--                    www.youtube.com@widge 
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
-- Any video footage used with this simulator remains
-- the property of their respective owners.
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --


* Access the game's Settings menu by pressing COIN1 or SERVICE while on the title screen, or while paused in-game.
* Pause the game by pressing START1 or PAUSE

* Either buttons 1 or 3 are the "Brake".
* Button 2 is the horn
* A suggested .ini file is provided

Video files can be downloaded from Archive.org

https://archive.org/details/@themanwithnoplan?query=driver&and%5B%5D=mediatype%3A%22movies%22

This link will take you to a page showing 7 archives.  We need 6 of them.
Ignore the one in the middle called "Sega Video Driver: California Chase Road Race" which is a compilation of two of the others.

Download only the largest MP4 file from each of the 6 remaining archives, 
Ignore all other files.  there may be other video formats but they are of no better quality and are bigger in file size, so stick to MP4.
Only the largest MP4 file in each of the 6 archives is needed.


Rename the files as follows:

  English language:
    calichase.mp4  (Caliornia Chase)
    roadracer.mp4  (Road Racer)
    pursuit.mp4    (Police Pursuit)
  
  Japanese language
    seaside.mp4    (Seaside Drive)
    halahara.mp4   (Halahara Touring)
    patrolman.mp4  (I am a Patrolman)


To convert them to the M2V/OGG format required by Hypseus, use the following ffmpeg commands (changing all 4 instances of `gamename` as appropriate):
    ffmpeg -i gamename.mp4 -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video -vf "scale=-2:450,pad=800:450:(ow-iw)/2:(oh-ih)/2, crop=800:450" gamename.m2v
    ffmpeg -i gamename.mp4 -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k gamename.ogg

Move the resulting .m2v and .ogg files to Video Driver's `video` subfolder, then you can delete the mp4 downloads.

*(By the time this game is released, there will likely be an archive of this game including the video files already converted.)*


Apply the "-usealt" argument to define the start game within the zip.
See: https://github.com/DirtBagXon/hypseus_singe_data/tree/master/00-zip-roms


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- calichase.daphne            (Symbolic link)
|    |-- halahara.daphne             (Symbolic link)
|    |-- patrolman.daphne            (Symbolic link)
|    |-- pursuit.daphne              (Symbolic link)
|    |-- roadracer.daphne            (Symbolic link)
|    |-- seaside.daphne              (Symbolic link)
|    |
|    |-- videodriver
|    |    |
|    |    |-- videodriver.zip         (Main LUA ZIP ROM file)
|    |    |-- calichase.txt           (Framefile from install zip)
|    |    |-- halahara.txt            (Framefile from install zip)
|    |    |-- patrolman.txt           (Framefile from install zip)
|    |    |-- pursuit.txt             (Framefile from install zip)
|    |    |-- roadracer.txt           (Framefile from install zip)
|    |    |-- seaside.txt             (Framefile from install zip)
|    |    |-- calichase.commands      (Optional)
|    |    |-- halahara.commands       (Optional)
|    |    |-- patrolman.commands      (Optional)
|    |    |-- pursuit.commands        (Optional)
|    |    |-- roadracer.commands      (Optional)
|    |    |-- seaside.commands        (Optional)
|    |    |
|    |    |-- video
|    |    |    |
|    |    |    |--calichase.m2v
|    |    |    |--halahara.m2v
|    |    |    |--patrolman.m2v
|    |    |    |--pursuit.m2v
|    |    |    |--roadracer.m2v
|    |    |    |--seaside.m2v
|    |    |    |--calichase.ogg
|    |    |    |--halahara.ogg
|    |    |    |--patrolman.ogg
|    |    |    |--pursuit.ogg
|    |    |    |--roadracer.ogg
|    |    |    |--seaside.ogg


for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- videodriver
|    |    |
|    |    |-- videodriver.zip         (Main LUA ZIP ROM file)
|    |    |-- calichase.txt           (Framefile from install zip)
|    |    |-- halahara.txt            (Framefile from install zip)
|    |    |-- patrolman.txt           (Framefile from install zip)
|    |    |-- pursuit.txt             (Framefile from install zip)
|    |    |-- roadracer.txt           (Framefile from install zip)
|    |    |-- seaside.txt             (Framefile from install zip)
|    |    |
|    |    |-- video
|    |    |    |
|    |    |    |--calichase.m2v
|    |    |    |--halahara.m2v
|    |    |    |--patrolman.m2v
|    |    |    |--pursuit.m2v
|    |    |    |--roadracer.m2v
|    |    |    |--seaside.m2v
|    |    |    |--calichase.ogg
|    |    |    |--halahara.ogg
|    |    |    |--patrolman.ogg
|    |    |    |--pursuit.ogg
|    |    |    |--roadracer.ogg
|    |    |    |--seaside.ogg
|    |    |    |



