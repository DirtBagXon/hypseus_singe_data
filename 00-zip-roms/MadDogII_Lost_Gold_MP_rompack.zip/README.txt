## MADDOG II: The Lost Gold (HYPSEUS SINGE MULTIPLAYER EDITION)


The files in this package should be installed alongside the required game video (m2v) and audio (ogg) files.

From version 2.11.2, Hypseus Singe supports zipped LUA (zlua) ROMS.

You will need to place the files from this package into your maddog2-hd folder with the new maddog2-hd m2v and ogg multiplayer media files.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- maddog2-hd.daphne
|    |    |
|    |    |-- maddog2-mp.m2v       (New 2-player media)
|    |    |-- maddog2-mp.ogg       (New 2-player media)
|    |    |-- maddog2-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- maddog2-hd.txt       (Framefile from install zip)
|    |    |-- maddog2-hd.commands  (Optional)
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- maddog2-hd
|    |    |
|    |    |-- maddog2-mp.m2v       (New 2-player media)
|    |    |-- maddog2-mp.ogg       (New 2-player media)
|    |    |-- maddog2-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- maddog2-hd.txt       (Framefile from install zip)
|    |
