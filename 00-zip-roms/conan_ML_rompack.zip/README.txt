## CONAN IL RAGAZZO DEL FUTURO multi-language edition

The files in this package should be installed alongside the required game video (m2v) and mullti language (-it) audio (ogg) files.

Hypseus Singe version 2.11.5 or above is required for this game.

You will need to place the files from this package into your conan folder, alongside the m2v and ogg files - Note: these are newly re-created 4:3 ratio files for this release.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- conan.daphne
|    |    |
|    |    |-- conan.zip       (Main LUA ZIP ROM file)
|    |    |-- conan.txt       (Framefile from install zip)
|    |    |-- conan.commands  (Optional)
|    |    |-- video
|    |    |-- |
|    |    |   |-- .m2v and multi-language .ogg files
|    |    |
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- conan
|    |    |
|    |    |-- conan.zip       (Main LUA ZIP ROM file)
|    |    |-- conan.txt       (Framefile from install zip)
|    |    |-- conan.commands  (Optional)
|    |    |-- video
|    |    |-- |
|    |    |   |-- .m2v and multi-language .ogg files
|    |    |
|    |
