## Gallagher's Gallery (HYPSEUS SINGE MULTIPLAYER EDITION)


The files in this package should be installed alongside the required game video (m2v) and audio (ogg) files. These are new video and audio files for the 2 player version.

From version 2.11.2, Hypseus Singe supports zipped LUA (zlua) ROMS.

You will need to place the files from this package into your gallagher folder, alongside the new m2v and ogg files from archive.org.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- gallagher.daphne
|    |    |
|    |    |-- gallagher.m2v       (New 2-player media)
|    |    |-- gallagher.ogg       (New 2-player media)
|    |    |-- gallagher.zip       (Main LUA ZIP ROM file)
|    |    |-- gallagher.txt       (Framefile from install zip)
|    |    |-- gallagher.commands  (Optional)
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- gallagher
|    |    |
|    |    |-- gallagher.m2v       (New 2-player media)
|    |    |-- gallagher.ogg       (New 2-player media)
|    |    |-- gallagher.zip       (Main LUA ZIP ROM file)
|    |    |-- gallagher.txt       (Framefile from install zip)
|    |
