#!/bin/bash

# Prompt the user about the Raspberry Pi model
read -p "Are you using a Raspberry Pi 4 (or similar) or a Raspberry Pi 5? (Enter 4 or 5): " pi_version

if [ "$pi_version" == "5" ]; then
    resX=960
    resY=720
    resZ=1280
    resW=720
    echo "Setting resolution for Raspberry Pi 5..."
else
    resX=512
    resY=384
    resZ=640
    resW=360
    echo "Setting resolution for Raspberry Pi 4 (or similar)..."
fi


# Check if FFmpeg is installed
if ! command -v ffmpeg &> /dev/null
then
    echo "FFmpeg is not installed. Installing..."

    # Update package list and install FFmpeg
    sudo apt update
    sudo apt install -y ffmpeg

    echo "FFmpeg has been installed."
fi

# Check if YT-DLP is installed
if ! command -v yt-dlp &> /dev/null
then
    echo "YT-DLP is not installed. Installing..."
    
    # Update package list and install YT-DLP
    sudo apt update
    sudo apt install -y yt-dlp
    
    echo "YT-DLP has been installed."
fi


# Download videos using yt-dlp
yt-dlp -o cpower1.mkv https://www.youtube.com/watch?v=gzd4dL4rG_g
yt-dlp -o cpower2.mkv https://www.youtube.com/watch?v=VLFy158bf10
yt-dlp -o cpower3.mkv https://www.youtube.com/watch?v=cEFTBC5-8sI
yt-dlp -o cpowergh.mkv https://www.youtube.com/watch?v=UCXZT5XaRIw
yt-dlp -o cpower4.mkv https://www.youtube.com/watch?v=WQg-JaVCVgQ

# Convert videos using FFmpeg
ffmpeg -i "cpower1.mkv" -vf "scale=${resX}:${resY}" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video "cpower1.m2v"
ffmpeg -i "cpower1.mkv" -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k "cpower1.ogg"

ffmpeg -i "cpower2.mkv" -vf "scale=${resX}:${resY}" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video "cpower2.m2v"
ffmpeg -i "cpower2.mkv" -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k "cpower2.ogg"

ffmpeg -i "cpower3.mkv" -vf "scale=${resX}:${resY}" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video "cpower3.m2v"
ffmpeg -i "cpower3.mkv" -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k "cpower3.ogg"

ffmpeg -i "cpowergh.mkv" -vf "scale=${resX}:${resY}" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video "cpowergh.m2v"
ffmpeg -i "cpowergh.mkv" -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k "cpowergh.ogg"

ffmpeg -i "cpower4.mkv" -vf "scale=${resZ}:${resW}" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video "cpower4.m2v"
ffmpeg -i "cpower4.mkv" -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k "cpower4.ogg"

