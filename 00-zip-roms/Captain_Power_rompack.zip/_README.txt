Captain Power VHS Game Simulator for Hypseus
    created by Widge, 2024
    www.youtube.com/@widge

This game was developed as a work of fan art.
All characters, names and source material are the property of their respective owners.
This game is made purely for entertainment purposes, and no commercial profit is being made from its distribution.

Special thanks to Dan O'Byrne for creating the video, "Skill Level 4: Lord Dread Strikes Back".  www.youtube.com/@obyrnedd



=============
 How to Play
=============

Playing the game is not exactly the same as it was with original equipment.  Consider this a "reimagining" of the classic game, rather than an entirely faithful reproduction.

- The objective is to gain as many points as possible by shooting enemy targets, while also avoiding taking damage (and losing points) from enemy fire.
Shoot at flashing RED targets to gain 50 points per hit.
- Avoid allowing your sights to pass over flashing YELLOW regions. This represents your jet flying through enemy fire and you lose 1 point for every video frame that your jet is in danger.
- Your Jet can only take so much punishment.  You start the game with five POWERPOINTS (aka "lives"). You lose one powerpoint for every 100 points of damage taken. If you lose all of your powerpoints (i.e 500 points of damage), your Jet explodes and you fail your mission.
- You can check your powerpoints level at any time during a mission. Pressing the secondary button (usually Mouse Right) will give you an audible count of your remaining powerpoints.
- Your jet is equipped with a shield that you can activate to avoid taking damage. Hold your trigger button and the shield will activate and remain active until you release the trigger. You will be unable to return fire while your shield is active.
- If you complete your mission, you will also be awarded a completion bonus. The bonus is equal to 100x your accuracy percentage.



=======
 Notes
=======

This game requires Hypseus Singe v2.11.3.  It will not work on earlier versions, so make sure you update.

The -texturestream argument to Hypseus will disable pixel reading calls required in this game. Some distributions may enable this argument by default to remove an SDL2 texture conversion introduced in SDL2 2.0.16. Consult your distribution documentation and check the hardware's ability to run SDL_TEXTUREACCESS_TARGET without heavy performance penalty.
Without SDL_TEXTUREACCESS_TARGET this game will not function.

If you wish to disable the targetting reticule, then use the "-nocrosshair " parameter.  On Windows, this can be added to the command line in your .bat file. on Raspberry Pi, you can include it in your .commands file.

If you wish to disable the laser beams, then you can make a simple edit to the individual games's .singe file, contained in the .zip file (e.g. cpower1.singe). Change "lasers = true" to "lasers = false". 



==============================================
 Raspberry Pi 4 and other low powered devices
==============================================

The guidance below is written assuming that you'll be playing on either a Raspberry Pi 5 or a PC that is at least as powerful. For everyone else, read this section first.
The game can be played on a Pi 4 but there are some caveats.
1. At the time of writing, RetroPie on Pi 4 limits SDL2 to version 2.0.10 which is too old to deal with the pixel detection necessary for this game.  It is possible to force Retropie to update SDL2 to version 2.26.3 which will allow Captain Power to function, but the side-effects of such a "hack" are unknown.
2. It is important that the device running Hypseus is able to play the video at its full framerate with very few dropped frames.  Consequently, the video resolution will need to be significantly reduced to be able to play effectively on a Pi4 or similar low-powered devices.  For Pi5 a 4:3 resolution of 960x720 and 16:9 resolution of 1280x720 yields good performance.  but for Pi4 the 4:3 resolution needs to go down to 512x384 and 16:9 down to 640x360.  The ffmpeg commands in the next section should be adjusted to account for these alternative resolutions.  Note that `cpower4` is the only 16:9 game.



===========================
 Obtaining the video files
===========================

The video files can be obtained via YouTube from RobotGangster.  These uploads in particular have been excellently converted from VHS in such a way that preserves the functionality of the flashing targets where other conversions do not. I recommend using yt-dlp to download them and ffmpeg to convert them to m2v and ogg formats.

** Windows BAT and Linux SH scripts have been provided to automate the download and conversion for you. If you prefer to do things manually, then read on.**


On Linux, including Raspberry Pi, they can be installed using the following command:  "sudo apt install yt-dlp ffmpeg -y"
Windows versions can be downloaded from https://github.com/yt-dlp/yt-dlp/releases and https://www.ffmpeg.org/download.html. For Windows, it's recommended to run yt-dlp from the ffmpeg "bin" folder.


Downloading and conversion of the video files can be accomplished with the following commands:

cd ~/RetroPie/roms/daphne/captainpower/video/
yt-dlp -o "cpower1.mkv" https://www.youtube.com/watch?v=gzd4dL4rG_g
yt-dlp -o "cpower2.mkv" https://www.youtube.com/watch?v=VLFy158bf10
yt-dlp -o "cpower3.mkv" https://www.youtube.com/watch?v=cEFTBC5-8sI

ffmpeg -i cpower1.mkv -vf "scale=960:720" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video cpower1.m2v
ffmpeg -i cpower1.mkv -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k cpower1.ogg
ffmpeg -i cpower2.mkv -vf "scale=960:720" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video cpower2.m2v
ffmpeg -i cpower2.mkv -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k cpower2.ogg
ffmpeg -i cpower3.mkv -vf "scale=960:720" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video cpower3.m2v
ffmpeg -i cpower3.mkv -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k cpower3.ogg

The Greatest Hits Collection:

yt-dlp -o "cpowergh.mkv" https://www.youtube.com/watch?v=UCXZT5XaRIw

ffmpeg -i cpowergh.mkv -vf "scale=960:720" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video cpowergh.m2v
ffmpeg -i cpowergh.mkv -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k cpowergh.ogg


There also exists a fan-made fourth installment to the VHS game series called "Lord Dread Strikes Back (Skill Level: 4)".  This was made by Daniel O'Byrne.
It can be seen on Youtube here: https://www.youtube.com/watch?v=WQg-JaVCVgQ
And a video of this game being played with the XT-7 toy can be seen here: https://www.youtube.com/watch?v=KJYC_q8SdOo

The video file can be downloaded directly from his Google Drive with this link:
https://drive.google.com/file/d/1XqYkkM6MtYWwZ2svwLfNYCtQHlRVkudc/view?usp=drive_link

Rename it it cpower4.mkv, then convert it into the m2v and ogg formats using theses ffmpeg commands:

ffmpeg -i "cpower4.mkv" -vf "scale=1280:720" -an -qscale:v 4 -b:v 6000k -codec:v mpeg2video "cpower4.m2v"
ffmpeg -i "cpower4.mkv" -ss 00:00:00.110 -vn -c:a libvorbis -ar 44100 -map a -b:a 160k "cpower4.ogg"


Once completed, confirm that you have an .m2v and an .ogg file for each episode then the .mkv files can be deleted.



===========
 SETTNG UP
===========

For RetroPie users on Raspberry Pi:

 - you need to create symbolic links in your daphne roms folder, all pointing to "./captainpower".
 - The symlink filenames should be "cpower1.daphne", "cpower2.daphne", "cpower3.daphne", "cpowergh.daphne" and "cpower4.daphne"
 - Run these commands from terminal to create the symbolic links needed for the Captain Power games to run:
		cd ~/RetroPie/roms/daphne
		ln -s captainpower cpower1.daphne
		ln -s captainpower cpower2.daphne
		ln -s captainpower cpower3.daphne
		ln -s captainpower cpowergh.daphne
		ln -s captainpower cpower4.daphne

For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- cpower1.daphne               (Symbolic link)
|    |-- cpower2.daphne               (Symbolic link)
|    |-- cpower3.daphne               (Symbolic link)
|    |-- cpower4.daphne               (Symbolic link)
|    |-- cpowergh.daphne              (Symbolic link)
|    |
|    |-- captainpower
|    |    |
|    |    |-- captainpower.zip         (Main LUA ZIP ROM file)
|    |    |-- cpower1.txt              (Framefile from install zip)
|    |    |-- cpower2.txt              (Framefile from install zip)
|    |    |-- cpower3.txt              (Framefile from install zip)
|    |    |-- cpower4.txt              (Framefile from install zip)
|    |    |-- cpowergh.txt             (Framefile from install zip)
|    |    |-- cpower1.commands         (Optional)
|    |    |-- cpower2.commands         (Optional)
|    |    |-- cpower3.commands         (Optional)
|    |    |-- cpower4.commands         (Optional)
|    |    |-- cpowergh.commands        (Optional)
|    |    |
|    |    |-- video
|    |    |    |
|    |    |    |--cpower1.m2v
|    |    |    |--cpower2.m2v
|    |    |    |--cpower3.m2v
|    |    |    |--cpower4.m2v
|    |    |    |--cpowergh.m2v
|    |    |    |--cpower1_title.m2v
|    |    |    |--cpower2_title.m2v
|    |    |    |--cpower3_title.m2v
|    |    |    |--cpowergh_title.m2v
|    |    |    |--gameover.m2v
|    |    |    |--cpower1.ogg
|    |    |    |--cpower2.ogg
|    |    |    |--cpower3.ogg
|    |    |    |--cpower4.ogg
|    |    |    |--cpowergh.ogg
|    |    |    |--gameover.ogg
|    |    |    |

Finally, make sure the captainpower folder and its contents are all owned by the user and have read and write permissions enabled.




for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- captainpower
|    |    |
|    |    |-- captainpower.zip         (Main LUA ZIP ROM file)
|    |    |-- cpower1.txt		       (Framefile from install zip)
|    |    |-- cpower2.txt		       (Framefile from install zip)
|    |    |-- cpower3.txt		       (Framefile from install zip)
|    |    |-- cpower4.txt		       (Framefile from install zip)
|    |    |-- cpowergh.txt		       (Framefile from install zip)
|    |    |
|    |    |-- video
|    |    |    |
|    |    |    |--cpower1.m2v
|    |    |    |--cpower2.m2v
|    |    |    |--cpower3.m2v
|    |    |    |--cpower4.m2v
|    |    |    |--cpowergh.m2v
|    |    |    |--cpower1_title.m2v
|    |    |    |--cpower2_title.m2v
|    |    |    |--cpower3_title.m2v
|    |    |    |--cpowergh_title.m2v
|    |    |    |--gameover.m2v
|    |    |    |--cpower1.ogg
|    |    |    |--cpower2.ogg
|    |    |    |--cpower3.ogg
|    |    |    |--cpower4.ogg
|    |    |    |--cpowergh.ogg
|    |    |    |--gameover.ogg
|    |    |    |


