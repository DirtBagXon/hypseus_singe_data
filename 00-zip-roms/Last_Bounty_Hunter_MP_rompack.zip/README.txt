## LAST BOUNTY HUNTER (HYPSEUS SINGE MULTIPLAYER EDITION)


The files in this package should be installed alongside the required game video (m2v) and audio (ogg) files. These are new video and audio files for the 2 player version.

From version 2.11.2, Hypseus Singe supports zipped LUA (zlua) ROMS.

You will need to place the files from this package into your lbh-hd folder, alongside new m2v and ogg files from archive.org.

Note: You cannot use existing video and audio files from previous lbh games, the new files are now specific to the 2 player version, with extra content and aspect ratio fixes.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- lbh-hd.daphne
|    |    |
|    |    |-- lbh-mp.m2v       (New 2-player media)
|    |    |-- lbh-mp.ogg       (New 2-player media)
|    |    |-- lbh-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- lbh-hd.txt       (Framefile from install zip)
|    |    |-- lbh-hd.commands  (Optional)
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- lbh-hd
|    |    |
|    |    |-- lbh-mp.m2v       (New 2-player media)
|    |    |-- lbh-mp.ogg       (New 2-player media)
|    |    |-- lbh-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- lbh-hd.txt       (Framefile from install zip)
|    |
