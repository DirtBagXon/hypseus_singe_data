Rename the Video folders, or change the Road_Blaster.txt
framefile content to point to the Video_SD sources if preferred.
