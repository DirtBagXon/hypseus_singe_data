## WHO SHOT JOHNNY ROCK (HYPSEUS SINGE MULTIPLAYER EDITION)


The files in this package should be installed alongside the required game video (m2v) and audio (ogg) files. These are new video and audio files for the 2 player version.

From version 2.11.2, Hypseus Singe supports zipped LUA (zlua) ROMS. This game requires version 2.11.5 for enhanced features.

You will need to place the files from this package into your wsjr-hd folder, alongside new m2v and ogg files from archive.org.

Note: You cannot use existing video and audio files from previous johnnyrock games, the new files are now specific to the 2 player version.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- wsjr-hd.daphne
|    |    |
|    |    |-- wsjr.m2v          (New 2-player media)
|    |    |-- wsjr.ogg          (New 2-player media)
|    |    |-- wsjr-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- wsjr-hd.txt       (Framefile from install zip)
|    |    |-- wsjr-hd.commands  (Optional)
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- wsjr-hd
|    |    |
|    |    |-- wsjr.m2v          (New 2-player media)
|    |    |-- wsjr.ogg          (New 2-player media)
|    |    |-- wsjr-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- wsjr-hd.txt       (Framefile from install zip)
|    |
