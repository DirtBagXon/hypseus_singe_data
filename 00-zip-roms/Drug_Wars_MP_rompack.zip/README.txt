## CRIME PATROL 2 DRUG WARS (HYPSEUS SINGE MULTIPLAYER EDITION)


The files in this package should be installed alongside the required game video (m2v) and audio (ogg) files.

From version 2.11.2, Hypseus Singe supports zipped LUA (zlua) ROMS.

You will need to place the files from this package into your drugwars-hd folder, alongside the m2v and ogg files that you already have.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- drugwars-hd.daphne
|    |    |
|    |    |-- drugwars.m2v
|    |    |-- drugwars.ogg
|    |    |-- drugwars-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- drugwars-hd.txt       (Framefile from install zip)
|    |    |-- drugwars-extra.m2v    (from install zip)
|    |    |-- drugwars-extra.ogg    (from install zip)
|    |    |-- drugwars-hd.commands  (Optional)
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- drugwars-hd
|    |    |
|    |    |-- drugwars.m2v
|    |    |-- drugwars.ogg
|    |    |-- drugwars-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- drugwars-hd.txt       (Framefile from install zip)
|    |    |-- drugwars-extra.m2v    (from install zip)
|    |    |-- drugwars-extra.ogg    (from install zip)
|    |