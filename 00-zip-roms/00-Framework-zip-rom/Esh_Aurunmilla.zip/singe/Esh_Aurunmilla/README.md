# Hypseus Singe
  
## ESH'S AURUNMILLA

Modified by:    Maximi1ium (2024)

### Maximi1ium Remix:  
New Moves added to the game.  
Original Singe 2 ESH'S AURUNMILLA movie converted to 1440 x 1080.  
Hypseus Singe Bezels + batch files, Scoreboard Ready.  
Alternative moves added, sometimes is O.K. to hit ACTION or Up, Down, Left or Right.  
Move Guide enabled by default with new graphics, it can be disable in game options.  
More levels divided into "scenes", so player do not have to play the entire level after death.  
Original asterisks movement guide were added to the movie on previous release, is part of the video.  
Timing tweaks on HOLD and RELEASE originally added on Singe 2.  
Full conversion for Framework 3.32a by Karris (2021), Framework folder included with the game.  
Play Style: Tier play capable, disabled by default, Play random levels exept Level 001, 009 to 011.  

## Starting game

_Example:_

`hypseus singe vldp -framefile singe/Esh_Aurunmilla/Esh_Aurunmilla.txt -script singe/Esh_Aurunmilla/Esh_Aurunmilla.singe`

