## MADDOG MCCREE (HYPSEUS SINGE MULTIPLAYER EDITION)


The files in this package should be installed alongside the required game video (m2v) and audio (ogg) files.

From version 2.11.2, Hypseus Singe supports zipped LUA (zlua) ROMS.

You will need to place the files from this package into your maddog-hd folder with the existing maddog-hd m2v and ogg files.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- maddog-hd.daphne
|    |    |
|    |    |-- maddog-hd.m2v
|    |    |-- maddog-hd.ogg
|    |    |-- maddog-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- maddog-hd.txt       (Framefile from install zip)
|    |    |-- maddog-hd.commands  (Optional)
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- maddog-hd
|    |    |
|    |    |-- maddog-hd.m2v
|    |    |-- maddog-hd.ogg
|    |    |-- maddog-hd.zip       (Main LUA ZIP ROM file)
|    |    |-- maddog-hd.txt       (Framefile from install zip)
|    |
