## Platoon (HYPSEUS SINGE MULTIPLAYER EDITION)

The files in this package should be installed alongside the required game video (m2v) and (ogg) files.

Hypseus Singe version 2.11.5 or above is required for this game.

You will need to place the files from this package into your platoon folder, alongside the m2v and ogg files.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- platoon.daphne
|    |    |
|    |    |-- platoon.m2v       (New 2-player media)
|    |    |-- platoon.ogg       (English Audio)
|    |    |-- platoon.zip       (Main LUA ZIP ROM file)
|    |    |-- platoon.txt       (Framefile from install zip)
|    |    |-- platoon.commands  (Optional)
|    |    |
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- platoon
|    |    |
|    |    |-- platoon.m2v       (New 2-player media)
|    |    |-- platoon.ogg       (English Audio)
|    |    |-- platoon.zip       (Main LUA ZIP ROM file)
|    |    |-- platoon.txt       (Framefile from install zip)
|    |    |
|    |
